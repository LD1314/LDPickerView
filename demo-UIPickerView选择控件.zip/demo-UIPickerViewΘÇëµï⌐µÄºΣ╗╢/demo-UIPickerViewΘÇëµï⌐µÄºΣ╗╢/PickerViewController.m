//
//  PickerViewController.m
//  demo-UIPickerView选择控件
//
//  Created by iOS Tedu on 16/8/10.
//  Copyright © 2016年 huaxu. All rights reserved.
//

#import "PickerViewController.h"
#import "LDPickerView.h"

@interface PickerViewController ()

@property (nonatomic, strong) LDPickerView *pickerView;
@property (nonatomic, weak) UILabel *label;

@end

@implementation PickerViewController

- (LDPickerView *)pickerView {
    if (!_pickerView) {
        _pickerView = [[LDPickerView alloc] initWithSelectArray:@[@"北京", @"上海", @"广州", @"深圳", @"重庆", @"武汉", @"天津"]];
    }
    
    return _pickerView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    
    UILabel *label = [UILabel new];
    label.backgroundColor = [UIColor greenColor];
    label.textColor = [UIColor whiteColor];
    label.frame = CGRectMake(50, 100, 200, 30);
    self.label = label;
    [self.view addSubview:label];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self.pickerView show];
    [self.pickerView didSelectTitleWithCompleteHandle:^(NSString *title) {
        self.label.text = title;
    }];
}

@end
